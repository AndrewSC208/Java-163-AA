/* Filename Tree.java */
/* Written by Andrew Meiling */
/* Written on January 28th, 2014 */
/* Chapter 1 */
/* Exercise # 7 */
/* Pgs 46 - 48 */
/* CIS163AA - Java Programming: level 1 */
/* Class # 11681 */

public class Tree {

	public static void main(String [] args) {
		
		System.out.println("   X    ");
		System.out.println("  XXX   ");
		System.out.println(" XXXXX  ");
		System.out.println("XXXXXXX ");
		System.out.println("   X    ");
			
	}

}