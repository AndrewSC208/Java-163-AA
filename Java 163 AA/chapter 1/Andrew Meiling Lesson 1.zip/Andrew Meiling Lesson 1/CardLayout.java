/* Filename CardLayout.java */
/* Written by Andrew Meiling */
/* Written on January 28th, 2014 */
/* Chapter 1 */
/* Exercise # 14 */
/* Pgs 46 - 48 */
/* CIS163AA - Java Programming: level 1 */
/* Class # 11681 */

public class CardLayout {

	public static void main(String [] args) {

		System.out.println(" ___________________________________" );
		System.out.println("|                                   |");
		System.out.println("| Programming |                     |");
		System.out.println("| Student     |                     |");
		System.out.println("|              Andrew Meiling       |");
		System.out.println("|              224 Dennis Ave       |");
		System.out.println("|              Republic, MO 65807   |");
		System.out.println("|              Phone: 417-761-1369  |");
		System.out.println("|              Fax:   417-763-8145  |");
		System.out.println("|___________________________________|");

	}

}