/* Filename BurmaShave.java */
/* Written by Andrew Meiling */
/* Written on January 28th, 2014 */
/* Chapter 1 */
/* Exercise # 13 */
/* Pgs 46 - 48 */
/* CIS163AA - Java Programming: level 1 */
/* Class # 11681 */


import javax.swing.JOptionPane;

public class BurmaShave {

	public static void main(String [] args) {

		JOptionPane.showMessageDialog(null, "I'd heard it praised");
		JOptionPane.showMessageDialog(null, "By drug store clearks");
		JOptionPane.showMessageDialog(null, "I tried the stuff");
		JOptionPane.showMessageDialog(null, "Hot dog!");
		JOptionPane.showMessageDialog(null, "It works");
		JOptionPane.showMessageDialog(null, "Burma-Shave");

	}
}
